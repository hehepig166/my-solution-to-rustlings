#[test]
fn passing() {
    asset!(true);
}
