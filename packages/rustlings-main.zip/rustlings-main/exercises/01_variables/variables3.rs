// variables3.rs
//
// Execute `rustlings hint variables3` or use the `hint` watch subcommand for a
// hint.

// I AM NOT DONE

fn main() {
    let x: i32;
    println!("Number {}", x);
}
