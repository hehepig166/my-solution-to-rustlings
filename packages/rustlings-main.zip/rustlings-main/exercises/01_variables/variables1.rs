// variables1.rs
//
// Make me compile!
//
// Execute `rustlings hint variables1` or use the `hint` watch subcommand for a
// hint.

// I AM NOT DONE

fn main() {
    x = 5;
    println!("x has the value {}", x);
}
