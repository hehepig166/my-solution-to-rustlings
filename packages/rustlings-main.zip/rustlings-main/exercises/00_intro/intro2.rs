// intro2.rs
//
// Make the code print a greeting to the world.
//
// Execute `rustlings hint intro2` or use the `hint` watch subcommand for a
// hint.

// I AM NOT DONE

fn main() {
    printline!("Hello there!")
}
