// functions1.rs
//
// Execute `rustlings hint functions1` or use the `hint` watch subcommand for a
// hint.

// I AM NOT DONE

fn main() {
    call_me();
}
